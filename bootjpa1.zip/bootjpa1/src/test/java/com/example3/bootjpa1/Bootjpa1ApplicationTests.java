package com.example3.bootjpa1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Bootjpa1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
